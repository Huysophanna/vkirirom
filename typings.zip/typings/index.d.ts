/// <reference path="globals/core-js/index.d.ts" />
/// <reference path="globals/whatwg-fetch/index.d.ts" />
/// <reference path="globals/whatwg-streams/index.d.ts" />
